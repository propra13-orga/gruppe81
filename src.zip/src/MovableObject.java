

public abstract class MovableObject extends GameObject {

	public MovableObject() {
		// TODO Auto-generated constructor stub
	}
	
}
